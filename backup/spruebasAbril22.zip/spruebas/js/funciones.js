// JavaScript Document

function eliminar(url)
{
	if (confirm("Realmente desea eliminar este Registro ? "))
	{
		window.location=url;
	}
	
}
