<?php
session_start();
class Config{

	private $dbh;
	private $datos;
	
	
	public function __construct(){
	
	
		$this->datos=array();
		$host="localhost";
		$db="test";
		$username="root";
		$passwrd="waga";
		$dsn="mysql:host=$host;dbname=$db";
		
		
		try{
		
			$this->dbh=new PDO($dsn,$username,$passwrd);
			$this->dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);
			
		}
		catch(Exception $e){
		
			$this->pdo=null;
			error_log("Error de con la bd".$e->getMessage());
		}
	
	}
	
	private function setDatos()
	{
		return $this->dbh->query("SET NAMES 'utf8'");
	}
	
	public function getDatos()
	{
		self::setDatos();
		$sql = "select * from estudiantes;";
		foreach ($this->dbh->query($sql) as $row)
		{
			$this->datos[] = $row;
		}
			return $this->datos;
			$this->dbh = null;
	}
	
	public function getDatosPorId()
	{
		self::setDatos();
		$sql = "select * from estudiantes where id_persona = ? ;";
		$stmt=$this->dbh->prepare($sql);
		if ($stmt->execute(array($_GET['id_persona'])));
		{
			while ($row = $stmt->fetch())
			{
				$this->datos[]=$row;
			}
		}
					
			return $this->datos;
			$this->dbh = null;
	}
	
	public function insertDatos()
	{
		self::setDatos();
		$sql = "insert into estudiantes values (null,?,?,?,?);";
		$stmt=$this->dbh->prepare($sql);
		
		$stmt->bindParam(1,$nombre);
		$stmt->bindParam(2,$correo);
		$stmt->bindParam(3,$tele);
		$stmt->bindParam(4,$pais);

		$nombre=strip_tags($_POST["nombre"]);
		$correo=strip_tags($_POST["correo"]);
		$tele=strip_tags($_POST["tele"]);
		$pais=strip_tags($_POST["pais"]);
		
		$stmt->execute();
		header("Location: insertar_datos.php?m=1");
	}
	
	// metodo que inserta x tabla 
public function insertxt($table, $vcols, $vvalues){  // recibe vcols y vvalues ( arreglo de arreglos )
	$cols	=	$vcols[0]; 							// bajamos un nivel del array  para columnas
	$values	=	$vvalues[0];						// bajamos un nivel del array  para valores
	$numvalues = count($values)-1;					// contador de total de elementos en el array
	array_splice($cols, $numvalues, 1);				// eleminar el ultimo elemento del array COLUMNAS * BOTON INSERTAR
	array_splice($values, $numvalues, 1);			// eleminar el ultimo elemento del array VALORES * BOTON INSERTAR
	// debug : echo "<br>cols<pre>"; print_r($cols); echo "</pre>";	echo "<br>vals<pre>"; print_r($values); echo "</pre>";		echo "<br>numvalues = $numvalues"; exit();
	$placeholder = array();
    for ($i = 0; $i < $numvalues; $i++){ 
		$placeholder[$i] = '?';						// llenar array placeholder con ? para armar el query
	}
	
    $sql = 'INSERT INTO '. $table . ' (`' . implode("`, `", $cols) . '`) ';		//armar query  de la forma insert into tabla (col1,colxxx) values (val1,valxxx);
    $sql.= 'VALUES (' . implode(", ", $placeholder) . ')';						//armar query
	//echo "<br>".$sql; exit();
    $stmt = $this->dbh->prepare($sql);
    for($i=0; $i < $numvalues; $i++){
        //echo "<br>stmt->bindParam($i+1, $values[$i])";   
		$stmt->bindParam($i+1, $values[$i]);								// bindParam para cada elemento del arreglo $values
	}
    
	$stmt->execute($values);												//exec insert

}
	
	public function deleteDatos()
	{
		$sql = "delete from estudiantes where id_persona = ?";
		$stmt = $this->dbh->prepare($sql);
		$stmt->bindParam(1,$id);
		$id=$_GET["id_persona"];
		$stmt->execute();
		
		header("location: editar_datos.php?m=1");
	}
	
	
	
	public function getProductos(){
		
		$stm=$this->pdo->prepare("SELECT productos.id,productos.producto,productos.precio,
										productos.vig,fotos.name FROM productos,fotos
										WHERE productos.id=fotos.idpro
										ORDER BY rand() LIMIT 0,10");
										
		$stm->execute();

		while($row=$stm->fetch()){
		
			$this->datos[]=$row;
		
		}		
		
		return $this->datos;
	
	}



}



?>
