<?php
require_once 'class/config.php';
if (isset($_POST) && $_POST[insertar]=='Insertar')
{
	print_r($_POST);//exit();echo count($_POST)-1;exit();
	$config	=	new Config();
	//foreach($_POST as $k=>$v ){
	//echo "<br>[$k] = $v";
		$cols[]		=	array_keys($_POST);
		$values[]	=	array_values($_POST);
	//echo "<BR>ANTES DE MANDAR LOS DATOS<br>cols<pre>"; print_r($cols); echo "</pre>";	echo "<br>vals<pre>"; print_r($values); echo "</pre>";		exit();
	
    $datos	=	$config->insertxt('estudiantes',$cols,$values);
}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insertar Datos XTABLA</title>
</head>

<body onload="document.form.reset();document.form.nombre.focus();">
<ul>
	<li><a href="ver_datos.php">Ver Datos</a></li>
    <li><a href="insertar_datos.php">Insertar Datos</a></li>
	<li><a href="insertar_datosxt.php">Insertar Datos XTABLA</a></li>    
    <li><a href="editar_datos.php">Modificar Datos</a></li>
    <li><a href="ver_datos.php">Eliminar Datos</a></li>
    <li><a href="ver_datos.php">Buscar Datos</a></li>
</ul>
<hr />
<?php
if (isset($_GET) and $_GET["m"]==1)
{
	?>
    <h3 style="color:#F00">El Registro se ha creado satisfactoriamente</h3>
    <?php
	
}
?>

<form name="ingreso" action="" method="post">

<h2>Insertar Datos XTABLA</h2>

Nombre: <input type="text" name="nombre" /> <br />
Mail:   <input type="text" name="correo" /> <br />
Télefono: <input type="text" name="telefono" /> <br />
Pais: <input type="text" name="pais" /> <br />

<input type="submit" name="insertar" value="Insertar">

</form>

</body>
</html>