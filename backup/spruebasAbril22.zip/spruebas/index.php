<?php
error_reporting(E_ALL);
//echo "algo va bien";exit();
require_once 'class/config.php';
$config=new Config();
$datos=$config->getDatos();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Pruebas con PHP PDO</title>
</head>

<body>
<ul>
	<li><a href="ver_datos.php">Ver Datos</a></li>
    <li><a href="insertar_datos.php">Insertar Datos</a></li>
    <li><a href="ver_datos.php">Modificar Datos</a></li>
    <li><a href="ver_datos.php">Eliminar Datos</a></li>
    <li><a href="ver_datos.php">Buscar Datos</a></li>
</ul>
<hr />

</body>
</html>
