<?php
require_once 'class/config.php';
if (isset($_POST) and $_POST["grabar"]=="si")
{
	//print_r($_POST);
	$config	=	new Config();
    $datos	=	$config->insertDatos();
}


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body onload="document.form.reset();document.form.nombre.focus();">
<ul>
	<li><a href="ver_datos.php">Ver Datos</a></li>
    <li><a href="insertar_datos.php">Insertar Datos</a></li>
    <li><a href="editar_datos.php">Modificar Datos</a></li>
    <li><a href="ver_datos.php">Eliminar Datos</a></li>
    <li><a href="ver_datos.php">Buscar Datos</a></li>
</ul>
<hr />
<?php
if (isset($_GET) and $_GET["m"]==1)
{
	?>
    <h3 style="color:#F00">El Registro se ha creado satisfactoriamente</h3>
    <?php
	
}
?>

<form name="ingreso" action="" method="post">

<h2>Ingreso de Datos</h2>

Nombre: <input type="text" name="nombre" /> <br />
Mail:   <input type="text" name="correo" /> <br />
Télefono: <input type="text" name="tele" /> <br />
Pais: <input type="text" name="pais" /> <br />

<input type="hidden" name="grabar" value="si" />
<input type="submit" name="Insertar" value="Insertar" />

</form>

</body>
</html>