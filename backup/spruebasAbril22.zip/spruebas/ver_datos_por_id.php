<?php
require_once 'class/config.php';
$config=new Config();
$datos=$config->getDatosPorId();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<ul>
	<li><a href="ver_datos.php">Ver Datos</a></li>
    <li><a href="insertar_datos.php">Insertar Datos</a></li>
    <li><a href="editar_datos.php">Modificar Datos</a></li>
    <li><a href="ver_datos.php">Eliminar Datos</a></li>
    <li><a href="ver_datos.php">Buscar Datos</a></li>
</ul>
<hr />
<?php

	
	foreach ($datos as $dat)
	{
		//print_r($row);
		echo $dat['id_persona'];
		echo '<br>';
		echo $dat['nombre'];
		echo '<br>';
		echo $dat['correo'];
		echo '<br>';
		echo $dat['telefono'];
		echo '<br>';
		echo $dat['pais'];
		echo "<hr>";
	}
    
	
?>
</body>
</html>