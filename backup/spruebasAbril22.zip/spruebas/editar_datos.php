<?php
require_once 'class/config.php';
$config=new Config();
$datos=$config->getDatos();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edición de Datos con PDO</title>
<script language="javascript" type="text/javascript" src="js/funciones.js"> </script>
</head>

<body>
<ul>
	<li><a href="ver_datos.php">Ver Datos</a></li>
    <li><a href="insertar_datos.php">Insertar Datos</a></li>
    <li><a href="editar_datos.php">Modificar Datos</a></li>
    <li><a href="ver_datos.php">Eliminar Datos</a></li>
    <li><a href="ver_datos.php">Buscar Datos</a></li>
</ul>
<hr />
<?php

	if (isset($_GET["m"]))
	{
		switch ($_GET["m"])
		{
			case '1':
			?>
            <h3 style="color:#F00">Los Datos Fueron Eliminados Exitosamente!!!</h3>
            <?php
			break;
		}
		
	}
	
	foreach ($datos as $dat)
	{
		//print_r($row);
		echo $dat['nombre'];
		echo "--";
		echo $dat['correo'];
		?>
		&nbsp;&nbsp;  
		<a href="javascript:void(0);" title="Editar Datos de <?php echo $dat['nombre']; ?>" onclick="eliminar('eliminar_datos.php?id_persona=<?php echo $dat['id_persona']; ?>');">
		<img src="images/ic_editar.gif" border=0 />
		</a>
        &nbsp;&nbsp;&nbsp;&nbsp; 
		<a href="javascript:void(0);" title="Eliminar Datos de <?php echo $dat['nombre']; ?>" onclick="eliminar('eliminar_datos.php?id_persona=<?php echo $dat['id_persona']; ?>');">
		<img src="images/ic_delete.gif" border=0 />
		</a>
        <?php
		//echo "--<a href='ver_datos_por_id.php?id_persona=".$dat["id_persona"]."'>Ver Datos Completos</a>";
			
		echo "<hr>";
	}
    
	
?>
</body>
</html>